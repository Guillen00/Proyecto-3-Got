var searchData=
[
  ['init_21',['init',['../classCommand.html#aae4905d9b35e5de25efa31ef994d9a18',1,'Command']]]
];
