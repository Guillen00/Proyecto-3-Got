var searchData=
[
  ['status_13',['status',['../classCommand.html#a76499afadb76c1b5eb9f0d93369dba62',1,'Command']]],
  ['sync_14',['sync',['../classCommand.html#add9c6c1e2a129401a3691f1180f0b860',1,'Command']]]
];
