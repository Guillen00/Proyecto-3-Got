var searchData=
[
  ['reset_23',['reset',['../classCommand.html#a377455d9f11d585111262b72f5741343',1,'Command']]],
  ['rollback_24',['rollback',['../classCommand.html#a18c5f0d4fb4f2d5b62bfbd1b30528876',1,'Command']]]
];
