var searchData=
[
  ['reset_10',['reset',['../classCommand.html#a377455d9f11d585111262b72f5741343',1,'Command']]],
  ['rollback_11',['rollback',['../classCommand.html#a18c5f0d4fb4f2d5b62bfbd1b30528876',1,'Command']]],
  ['rutadestino_12',['rutadestino',['../classCommand.html#a011ab171f6972c1af2d04afbf8c1bac0',1,'Command']]]
];
