var searchData=
[
  ['lista_5fagregados_27',['lista_agregados',['../classCommand.html#a5fd0f53744f9b687d92e6d3afcc77a1f',1,'Command']]],
  ['lista_5fpendientes_28',['lista_pendientes',['../classCommand.html#a04d85e37464920087c3a1c94c7058457',1,'Command']]]
];
